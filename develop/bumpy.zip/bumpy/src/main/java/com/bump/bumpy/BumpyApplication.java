package com.bump.bumpy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BumpyApplication {

	public static void main(String[] args) {
		SpringApplication.run(BumpyApplication.class, args);
	}

}
